// NEED import
import $ from 'jquery';
//import '@fancyapps/fancybox';
import 'slick-carousel';


import './js/';
// NEED import

// SCSS import
import './scss/style.scss';
//import './scss/compress.scss';
